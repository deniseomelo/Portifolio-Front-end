-- CreateTable
CREATE TABLE "Usuario" (
    "idUser" TEXT NOT NULL PRIMARY KEY,
    "nomeUser" TEXT NOT NULL,
    "senha" TEXT NOT NULL,
    "perfilUser" TEXT NOT NULL,
    "criacao" DATETIME DEFAULT CURRENT_TIMESTAMP,
    "alteracao" DATETIME DEFAULT CURRENT_TIMESTAMP
);

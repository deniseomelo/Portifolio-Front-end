import { Router } from "express";
import { usuarioController } from "./controllers/UsuarioController";

const router: Router = Router()

//Routes
router.get("/users/all", usuarioController.listar);
router.post("/users", usuarioController.criar);
router.put("/users", usuarioController.atualizar);
router.get("/users/:idUser", usuarioController.consultar);
router.delete("/users/:idUser", usuarioController.remover);

export { router };
